//////////////////////////////////////////////////// MENU ///////////////////////////////////////////////////////
var Menu_Btn = document.getElementById("Menu-Btn");
var Menu_Div = document.getElementById("Menu-Div");
var Nav_Btn = document.getElementById("Nav-Btn");
var Menu_Div_Box_Mother = document.getElementById("Menu-Div-Box-Mother")
Nav_Btn.addEventListener("click", function (){
    Menu_Div_Box_Mother.style.transitionProperty = "all";
    Menu_Div_Box_Mother.style.transitionDuration = "2.5s";
    Menu_Div.style.transitionProperty = "all";
    Menu_Div.style.transitionDuration = "1s";
    Menu_Div.style.width = "50%";
    Menu_Div.style.visibility = "visible";
    Menu_Btn.style.visibility = "visible";
    Menu_Div_Box_Mother.style.opacity = "1";
})
Menu_Btn.addEventListener("click", function (){
    Menu_Div_Box_Mother.style.transitionProperty = "all"
    Menu_Div_Box_Mother.style.transitionDuration = "0.2s"
    Menu_Div_Box_Mother.style.opacity = "0";
    Menu_Btn.style.transitionProperty = "all";
    Menu_Btn.style.transitionDuration = "0.5s";
    Menu_Btn.style.visibility = "hidden";
    Menu_Div.style.width = "0%";
    Menu_Div.style.visibility = "hidden";
})
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
document.getElementById("Information-Child-1").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-1").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-1").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات"
    document.getElementById("P-Information-Title-1").style.color = "white"
})
document.getElementById("Information-Child-1").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-1").style.backgroundColor = "white"
    document.getElementById("Bold-Information-1").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-1").style.color = "black"
})
document.getElementById("Information-Child-2").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-2").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-2").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات"
    document.getElementById("P-Information-Title-2").style.color = "white"
})
document.getElementById("Information-Child-2").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-2").style.backgroundColor = "white"
    document.getElementById("Bold-Information-2").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-2").style.color = "black"
})
document.getElementById("Information-Child-3").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-3").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-3").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات  توضیحات توضیحات"
    document.getElementById("P-Information-Title-3").style.color = "white"
})
document.getElementById("Information-Child-3").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-3").style.backgroundColor = "white"
    document.getElementById("Bold-Information-3").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-3").style.color = "black"
})
document.getElementById("Information-Child-4").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-4").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-4").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات"
    document.getElementById("P-Information-Title-4").style.color = "white"
})
document.getElementById("Information-Child-4").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-4").style.backgroundColor = "white"
    document.getElementById("Bold-Information-4").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-4").style.color = "black"
})
/////////////////////////////////////////////////////////////////////////////////////////////////////////
var  H2 = document.getElementById("H2-Page")
var IMG_1 = document.getElementById("Div-Direction-1")
var IMG_2 = document.getElementById("Div-Direction-2")
var IMG_3 = document.getElementById("Div-Direction-3")
var IMG_4 = document.getElementById("Div-Direction-4")
var IMG_5 = document.getElementById("Div-Direction-5")
var IMG_6 = document.getElementById("Div-Direction-6")
if (H2.innerText.length >= 13){
    IMG_6.style.backgroundColor = "#d7d643"
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
$(".Div-Description-Child").style.height = $(".Description-Div").style.height


