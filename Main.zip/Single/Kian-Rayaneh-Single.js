//////////////////////////////////////////////////// MENU ///////////////////////////////////////////////////////
var Menu_Btn = document.getElementById("Menu-Btn");
var Menu_Div = document.getElementById("Menu-Div");
var Nav_Btn = document.getElementById("Nav-Btn");
var Menu_Div_Box_Mother = document.getElementById("Menu-Div-Box-Mother")
Nav_Btn.addEventListener("click", function (){
    Menu_Div_Box_Mother.style.transitionProperty = "all";
    Menu_Div_Box_Mother.style.transitionDuration = "2.5s";
    Menu_Div.style.transitionProperty = "all";
    Menu_Div.style.transitionDuration = "1s";
    Menu_Div.style.width = "50%";
    Menu_Div.style.visibility = "visible";
    Menu_Btn.style.visibility = "visible";
    Menu_Div_Box_Mother.style.opacity = "1";
})
Menu_Btn.addEventListener("click", function (){
    Menu_Div_Box_Mother.style.transitionProperty = "all"
    Menu_Div_Box_Mother.style.transitionDuration = "0.2s"
    Menu_Div_Box_Mother.style.opacity = "0";
    Menu_Btn.style.transitionProperty = "all";
    Menu_Btn.style.transitionDuration = "0.5s";
    Menu_Btn.style.visibility = "hidden";
    Menu_Div.style.width = "0%";
    Menu_Div.style.visibility = "hidden";
})
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$("#Button-Question-1").click(function () {
    if (document.getElementById("P-Question-1").style.color === "red") {
        document.getElementById("P-Question-1").style.color = "black"
        document.getElementById("IMG-Question-1").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-1").innerText = ""
        document.getElementById("P-Answer-1").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-1").style.color = "red"
        document.getElementById("IMG-Question-1").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-1").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-1").style.marginBottom = "50px"
    }
})
$("#Button-Question-2").click(function (){
    if (document.getElementById("P-Question-2").style.color === "red"){
        document.getElementById("P-Question-2").style.color = "black"
        document.getElementById("IMG-Question-2").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-2").innerText = ""
        document.getElementById("P-Answer-2").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-2").style.color = "red"
        document.getElementById("IMG-Question-2").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-2").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-2").style.marginBottom = "50px"
    }
})
$("#Button-Question-3").click(function (){
    if (document.getElementById("P-Question-3").style.color === "red"){
        document.getElementById("P-Question-3").style.color = "black"
        document.getElementById("IMG-Question-3").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-3").innerText = ""
        document.getElementById("P-Answer-3").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-3").style.color = "red"
        document.getElementById("IMG-Question-3").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-3").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-3").style.marginBottom = "50px"
    }
})
$("#Button-Question-4").click(function (){
    if (document.getElementById("P-Question-4").style.color === "red"){
        document.getElementById("P-Question-4").style.color = "black"
        document.getElementById("IMG-Question-4").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-4").innerText = ""
        document.getElementById("P-Answer-4").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-4").style.color = "red"
        document.getElementById("IMG-Question-4").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-4").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-4").style.marginBottom = "50px"
    }
})
$("#Button-Question-5").click(function (){
    if (document.getElementById("P-Question-5").style.color === "red"){
        document.getElementById("P-Question-5").style.color = "black"
        document.getElementById("IMG-Question-5").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-5").innerText = ""
        document.getElementById("P-Answer-5").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-5").style.color = "red"
        document.getElementById("IMG-Question-5").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-5").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-5").style.marginBottom = "50px"
    }
})
$("#Button-Question-6").click(function (){
    if (document.getElementById("P-Question-6").style.color === "red"){
        document.getElementById("P-Question-6").style.color = "black"
        document.getElementById("IMG-Question-6").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-6").innerText = ""
        document.getElementById("P-Answer-6").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-6").style.color = "red"
        document.getElementById("IMG-Question-6").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-6").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-6").style.marginBottom = "50px"
    }
})
$("#Button-Question-7").click(function (){
    if (document.getElementById("P-Question-7").style.color === "red"){
        document.getElementById("P-Question-7").style.color = "black"
        document.getElementById("IMG-Question-7").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-7").innerText = ""
        document.getElementById("P-Answer-7").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-7").style.color = "red"
        document.getElementById("IMG-Question-7").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-7").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-7").style.marginBottom = "50px"
    }
})
$("#Button-Question-8").click(function (){
    if (document.getElementById("P-Question-8").style.color === "red"){
        document.getElementById("P-Question-8").style.color = "black"
        document.getElementById("IMG-Question-8").style.transform = "rotate(0deg)"
        document.getElementById("P-Answer-8").innerText = ""
        document.getElementById("P-Answer-8").style.marginBottom = "0"
    }
    else {
        document.getElementById("P-Question-8").style.color = "red"
        document.getElementById("IMG-Question-8").style.transform = "rotate(-90deg)"
        document.getElementById("P-Answer-8").innerText =
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک" +
            "در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک"
        document.getElementById("P-Answer-8").style.marginBottom = "50px"
    }
})
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
document.getElementById("Information-Child-1").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-1").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-1").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات"
    document.getElementById("P-Information-Title-1").style.color = "white"
})
document.getElementById("Information-Child-1").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-1").style.backgroundColor = "white"
    document.getElementById("Bold-Information-1").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-1").style.color = "black"
})
document.getElementById("Information-Child-2").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-2").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-2").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات"
    document.getElementById("P-Information-Title-2").style.color = "white"
})
document.getElementById("Information-Child-2").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-2").style.backgroundColor = "white"
    document.getElementById("Bold-Information-2").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-2").style.color = "black"
})
document.getElementById("Information-Child-3").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-3").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-3").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات  توضیحات توضیحات"
    document.getElementById("P-Information-Title-3").style.color = "white"
})
document.getElementById("Information-Child-3").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-3").style.backgroundColor = "white"
    document.getElementById("Bold-Information-3").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-3").style.color = "black"
})
document.getElementById("Information-Child-4").addEventListener("mouseover", function (){
    document.getElementById("Information-Child-4").style.backgroundColor = "#d02f2f"
    document.getElementById("Bold-Information-4").innerText = "✔ توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات"
    document.getElementById("P-Information-Title-4").style.color = "white"
})
document.getElementById("Information-Child-4").addEventListener("mouseleave", function (){
    document.getElementById("Information-Child-4").style.backgroundColor = "white"
    document.getElementById("Bold-Information-4").innerText = "✔ در زمینه کاری، هر کسی مهارت هایی دارد که شاید حتی به اندازه یک درصد از دیگری فراتر است"
    document.getElementById("P-Information-Title-4").style.color = "black"
})
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var  H2 = document.getElementById("H2-Page")
var IMG_1 = document.getElementById("Div-Direction-1")
var IMG_2 = document.getElementById("Div-Direction-2")
var IMG_3 = document.getElementById("Div-Direction-3")
var IMG_4 = document.getElementById("Div-Direction-4")
var IMG_5 = document.getElementById("Div-Direction-5")
var IMG_6 = document.getElementById("Div-Direction-6")
if (H2.innerText.length === 13){
    IMG_6.style.backgroundColor = "#d7d643"
}


